package test;

import static org.junit.jupiter.api.Assertions.*;

class OpenCommandTest {


}