
interface Command {
    void execute();
//    public String getCommandWord();

}
